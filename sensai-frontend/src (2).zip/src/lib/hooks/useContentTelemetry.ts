import { useEffect, useRef } from 'react';

interface TelemetryOptions {
    taskId?: string;
    userId?: string; // Kept for logic if needed, even though payload doesn't explicitly mention it in core (will be useful for headers/auth)
    containerRef: React.RefObject<HTMLDivElement>;
}

export function useContentTelemetry({ taskId, containerRef }: TelemetryOptions) {
    const telemetryData = useRef({
        // Core metrics
        task_id: taskId ? parseInt(taskId) : 0,
        completion_percentage: 0.0,
        total_watch_time: 0,
        duration: 0,
        scroll_depth: 0.0,
        time_spent: 0,
        expected_reading_time: 0,
        pause_count: 0,
        seek_back_count: 0,
        playback_speed_avg: 1.0,
        skip_forward_count: 0,
        active_reading_time: 0,
        smooth_scroll_score: 1.0,
        jump_scroll_count: 0,
        text_selections: 0,
        link_clicks: 0,
        tab_focus_time: 0,
        idle_time: 0,
        continuous_interaction_time: 0,
        revisit_frequency: 0,
        repeated_sections_count: 0,
        delayed_return: false,
        early_exit: false,

        // Metadata Sub-objects
        metadata: {
            device: {
                os: "unknown",
                browser: "unknown",
                device_type: "desktop",
                screen_resolution: "0x0",
                viewport_size: "0x0",
                timezone: "UTC",
                language: "en-US",
                connection_type: "unknown"
            },
            interaction: {
                rage_clicks: 0,
                dead_clicks: 0,
                copy_paste_count: 0,
                highlight_text_count: 0,
                typing_speed_wpm: 0,
                backspace_count: 0,
                time_to_first_interaction_ms: 0,
                rapid_scroll_count: 0,
                focus_losses: 0,
                mouse_trajectory_score: 1.0 // default to smooth if no tracking
            },
            chatbot: {
                total_messages_sent: 0,
                average_prompt_length: 0.0,
                time_spent_reading_ai_ms: 0,
                hints_requested: 0,
                regenerate_requests: 0,
                copy_from_chat_count: 0,
                paste_into_chat_count: 0,
                is_frustrated: false,
                sentiment_score: 0.0,
                user_interruption_count: 0,
                hesitation_time_ms: 0
            },
            custom_events: {
                clicked_feature_guide: false,
                theme_switched: "light"
            }
        }
    });

    const initTime = useRef<number>(Date.now());
    const lastActiveTime = useRef<number>(Date.now());
    const sendTimerRef = useRef<NodeJS.Timeout | null>(null);
    const lastScrollTop = useRef<number>(0);
    const clickTimestamps = useRef<number[]>([]);
    
    // Attempt tracking continuous interactions safely
    const currentContinuousSession = useRef<number>(0);

    // Initial setup for device matching
    useEffect(() => {
        if (typeof window === 'undefined') return;
        
        const nav = window.navigator as any;
        const data = telemetryData.current.metadata.device;
        
        data.screen_resolution = `${window.screen.width}x${window.screen.height}`;
        data.viewport_size = `${window.innerWidth}x${window.innerHeight}`;
        data.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        data.language = nav.language;
        data.connection_type = nav.connection?.effectiveType || "unknown";
        
        // Basic user agent string checking
        const ua = nav.userAgent;
        if (ua.includes("Win")) data.os = "Windows";
        else if (ua.includes("Mac")) data.os = "MacOS";
        else if (ua.includes("Linux")) data.os = "Linux";
        else if (ua.includes("Android")) data.os = "Android";
        else if (ua.includes("like Mac")) data.os = "iOS";
        
        if (ua.includes("Chrome")) data.browser = "Chrome";
        else if (ua.includes("Firefox")) data.browser = "Firefox";
        else if (ua.includes("Safari") && !ua.includes("Chrome")) data.browser = "Safari";
        else if (ua.includes("Edge")) data.browser = "Edge";
        
        data.device_type = /Mobile|Android|iP(ad|hone)/.test(ua) ? "mobile" : "desktop";
        
        // Check theme setup 
        telemetryData.current.metadata.custom_events.theme_switched = 
             document.documentElement.classList.contains("dark") ? "dark" : "light";
    }, []);

    useEffect(() => {
        if (!containerRef.current) return;
        const container = containerRef.current;
        let isTabActive = !document.hidden;
        
        // Ensure accurate initial times
        initTime.current = Date.now();
        lastActiveTime.current = Date.now();

        const updateActivityTime = () => {
            const now = Date.now();
            const timeSinceLastActive = now - lastActiveTime.current;
            
            // Interaction time marking
            if (telemetryData.current.metadata.interaction.time_to_first_interaction_ms === 0) {
                telemetryData.current.metadata.interaction.time_to_first_interaction_ms = now - initTime.current;
            }

            if (timeSinceLastActive > 15000 && isTabActive) {
                // If inactive for > 15s, mark excess as idle
                 telemetryData.current.idle_time += Math.round((timeSinceLastActive - 15000) / 1000);
                 
                 // Restart continuous interaction timer
                 if (currentContinuousSession.current > telemetryData.current.continuous_interaction_time) {
                     telemetryData.current.continuous_interaction_time = currentContinuousSession.current;
                 }
                 currentContinuousSession.current = 0;
            } else if (isTabActive) {
                 telemetryData.current.active_reading_time += Math.round(timeSinceLastActive / 1000);
                 currentContinuousSession.current += Math.round(timeSinceLastActive / 1000);
            }
            
            if (isTabActive) {
                telemetryData.current.tab_focus_time += Math.round(timeSinceLastActive / 1000);
            }

            lastActiveTime.current = now;
        };

        const handleScroll = () => {
            updateActivityTime();
            if (container) {
                const { scrollTop, scrollHeight, clientHeight } = container;
                const scrollDepthRatio = scrollHeight > clientHeight 
                    ? (scrollTop / (scrollHeight - clientHeight)) 
                    : 1.0;
                
                // Track max scroll depth as percentage
                if (scrollDepthRatio > telemetryData.current.scroll_depth) {
                    telemetryData.current.scroll_depth = scrollDepthRatio;
                    telemetryData.current.completion_percentage = scrollDepthRatio * 100;
                }

                // Detect Jump Scroll / Rapid Scroll
                const scrollDelta = Math.abs(scrollTop - lastScrollTop.current);
                if (scrollDelta > 300) {
                    telemetryData.current.jump_scroll_count += 1;
                    telemetryData.current.metadata.interaction.rapid_scroll_count += 1;
                }

                lastScrollTop.current = scrollTop;
            }
        };

        const handleVisibilityChange = () => {
            updateActivityTime();
            if (document.hidden) {
                telemetryData.current.metadata.interaction.focus_losses += 1;
                isTabActive = false;
            } else {
                isTabActive = true;
            }
        };

        const handleGlobalClick = (e: MouseEvent) => {
            updateActivityTime();
            
            // Dead / Rage Clicks tracking
            const now = Date.now();
            clickTimestamps.current.push(now);
            
            // Clean up old clicks (> 2 seconds ago)
            clickTimestamps.current = clickTimestamps.current.filter(t => now - t < 2000);
            
            if (clickTimestamps.current.length >= 3) {
                // 3 clicks in 2 seconds -> rage click
                telemetryData.current.metadata.interaction.rage_clicks += 1;
                clickTimestamps.current = []; // reset to avoid multi-counting
            } else {
                // If we clicked on something unclickable realistically (best effort)
                const target = e.target as HTMLElement;
                if (!['A', 'BUTTON', 'INPUT', 'TEXTAREA'].includes(target.tagName) && !target.onclick) {
                   telemetryData.current.metadata.interaction.dead_clicks += 1;
                } else if (target.tagName === 'A') {
                   telemetryData.current.link_clicks += 1;
                }
            }
        };
        
        const handleCopyPaste = () => {
            updateActivityTime();
            telemetryData.current.metadata.interaction.copy_paste_count += 1;
        };

        const handleSelection = () => {
            const selection = document.getSelection();
            if (selection && selection.toString().length > 0) {
                telemetryData.current.text_selections += 1;
                telemetryData.current.metadata.interaction.highlight_text_count += 1;
                updateActivityTime();
            }
        };

        // Media Event Handlers
        const handlePlay = (e: Event) => {
            updateActivityTime();
            const target = e.target as HTMLMediaElement;
            if (target && target.duration) {
                 telemetryData.current.duration = Math.round(target.duration);
            }
        };
        
        const handlePause = () => {
            updateActivityTime();
            telemetryData.current.pause_count += 1;
        };

        const handleSeeked = (e: Event) => {
            updateActivityTime();
            telemetryData.current.seek_back_count += 1; 
            // Generically treating all seeks as interactions as exact delta requires tracking previous currentTime
        };

        // Attach DOM Listeners natively
        container.addEventListener('scroll', handleScroll, { passive: true });
        document.addEventListener('visibilitychange', handleVisibilityChange);
        container.addEventListener('click', handleGlobalClick);
        document.addEventListener('copy', handleCopyPaste);
        document.addEventListener('paste', handleCopyPaste);
        document.addEventListener('selectionchange', handleSelection);
        
        container.addEventListener('play', handlePlay, true);
        container.addEventListener('pause', handlePause, true);
        container.addEventListener('seeked', handleSeeked, true);

        // Data Egress Dispatcher
        const sendData = (isFinal = false) => {
            updateActivityTime(); // calculate latest time markers

            // If continuous active session hasn't been saved yet to max
            if (currentContinuousSession.current > telemetryData.current.continuous_interaction_time) {
                 telemetryData.current.continuous_interaction_time = currentContinuousSession.current;
            }

            telemetryData.current.time_spent = Math.round((Date.now() - initTime.current) / 1000);
            
            // Set custom early_exit rules (example: left before 80% mark on unmount)
            if (isFinal) {
                if (telemetryData.current.scroll_depth < 0.8) {
                    telemetryData.current.early_exit = true;
                }
            }
            
            // Format strictly to the requested friend's JSON spec!
            const payload = {
                task_id: telemetryData.current.task_id,
                completion_percentage: Number(telemetryData.current.completion_percentage.toFixed(2)),
                total_watch_time: telemetryData.current.total_watch_time,
                duration: telemetryData.current.duration,
                scroll_depth: Number(telemetryData.current.scroll_depth.toFixed(2)),
                time_spent: telemetryData.current.time_spent,
                expected_reading_time: 300, // mock expected time or calculate dynamically based on container word count
                pause_count: telemetryData.current.pause_count,
                seek_back_count: telemetryData.current.seek_back_count,
                playback_speed_avg: telemetryData.current.playback_speed_avg,
                skip_forward_count: telemetryData.current.skip_forward_count,
                active_reading_time: telemetryData.current.active_reading_time,
                smooth_scroll_score: telemetryData.current.smooth_scroll_score,
                jump_scroll_count: telemetryData.current.jump_scroll_count,
                text_selections: telemetryData.current.text_selections,
                link_clicks: telemetryData.current.link_clicks,
                tab_focus_time: telemetryData.current.tab_focus_time,
                idle_time: telemetryData.current.idle_time,
                continuous_interaction_time: telemetryData.current.continuous_interaction_time,
                revisit_frequency: telemetryData.current.revisit_frequency,
                repeated_sections_count: telemetryData.current.repeated_sections_count,
                delayed_return: telemetryData.current.delayed_return,
                early_exit: telemetryData.current.early_exit,
                metadata: telemetryData.current.metadata
            };

            // Log explicitly to the browser console for easy visual testing!
            console.log("\n🚀 --- [TELEMETRY PAYLOAD DISPATCHING TO BACKEND] --- 🚀");
            console.log(JSON.stringify(payload, null, 2));
            console.log("-----------------------------------------------------------\n");

            fetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/signals/log`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
                keepalive: isFinal // very important for sending successfully on tab close 
            }).catch(e => console.warn("Backend telemetry error: ", e));
        };

        // Setup 10-second heartbeat to limit aggressive spam but keep data fresh
        sendTimerRef.current = setInterval(() => sendData(false), 10000);

        return () => {
            // cleanup all listeners
            sendData(true);
            if (sendTimerRef.current) clearInterval(sendTimerRef.current);
            container.removeEventListener('scroll', handleScroll);
            document.removeEventListener('visibilitychange', handleVisibilityChange);
            container.removeEventListener('click', handleGlobalClick);
            document.removeEventListener('copy', handleCopyPaste);
            document.removeEventListener('paste', handleCopyPaste);
            document.removeEventListener('selectionchange', handleSelection);
            
            container.removeEventListener('play', handlePlay, true);
            container.removeEventListener('pause', handlePause, true);
            container.removeEventListener('seeked', handleSeeked, true);
        };
    }, [taskId, containerRef]);
}
